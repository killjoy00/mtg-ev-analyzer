"""Render the Pack One launch REVIEW CUT. Real RFA gameplay is intentionally absent.

Run with Python, Pillow, numpy, piper-tts and ffmpeg. The project includes rendered
scene audio, so Piper and the model are unnecessary unless narration changes.
"""
from pathlib import Path
import json, math, re, shutil, subprocess, wave, zipfile
from functools import lru_cache
from PIL import Image, ImageDraw, ImageFont
import numpy as np

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / 'assets'
BUILD = ROOT / 'render'
OUT = ROOT / 'deliverables'
for p in [BUILD, OUT]: p.mkdir(exist_ok=True)
W, H, FPS = 1920, 1080, 24
PAGE = '#f7f8fa'
INK = '#101820'
MUTED = '#5f6770'
LINE = '#d5dbe1'
BLUE = '#1e4d7a'
DARK = '#15395b'
SOFT = '#e5edf4'
GOLD = '#976822'

SCENES = [
 dict(id='01', type='hook', title='What would you take?', kicker='THE DAILY DRAFT',
      narration="What would you take here? Give yourself a second. There are a couple of cards I'd be looking at.", hold=2.0),
 dict(id='02', type='source', title='A real draft.\nA trophy finish.', kicker='THE COMPARISON',
      narration="This pack comes from a real draft that ended in a trophy. In a moment, we'll see what that player took. But first, make your own pick.", hold=1.0),
 dict(id='03', type='insert', title='RFA pick one', kicker='GAMEPLAY INSERT 01', slot=22,
      subtitle='Show the pack, explain your choice, then reveal the trophy pick.',
      steps=['Readable pack + short thinking pause','Your actual pick + one clear reason','Original drafter reveal + natural reaction']),
 dict(id='04', type='brand', title='That’s Pack One.', kicker='EIGHT PICKS. YOUR CALL.',
      narration="That's the idea behind Pack One. I'm Ryan, and I built this because I enjoy the draft decisions almost as much as playing the games.", hold=.6),
 dict(id='05', type='thinking', title='The fun is\nin the decision.', kicker='FOR PEOPLE WHO LOVE TO DRAFT',
      narration="Looking at a pack, weighing a few options, and then finding out what somebody else chose is something I can happily spend a lot of time doing. Pack One turns that into a daily challenge.", hold=.6),
 dict(id='06', type='eight', title='8 picks.\n8 real trophy drafts.', kicker='ONE DAILY CHALLENGE',
      narration="Each challenge gives you eight picks from eight different real trophy drafts. You make your choices, compare them with the original drafters, and finish with a score you can share.", hold=1.0),
 dict(id='07', type='insert', title='RFA pick two', kicker='GAMEPLAY INSERT 02', slot=25,
      narration="Let's look at another one.",
      subtitle='Use a pack with an interesting choice between two cards.',
      steps=['Explain the two cards you are considering','Describe the actual tradeoff and lock your pick','Reveal the original choice and react']),
 dict(id='08', type='discussion', title='Pick. Compare.\nTalk it through.', kicker='THE BEST PART',
      narration="Those are the decisions I find interesting. Sometimes you immediately understand the other player's choice. Sometimes you still prefer your own pick. Either way, you've got something to think about or argue about with your draft group.", hold=1.0),
 dict(id='09', type='insert', title='The finished run', kicker='GAMEPLAY INSERT 03', slot=9,
      narration="Here's how that run finished.",
      subtitle='Insert the actual RFA result. Keep the score and reaction authentic.',
      steps=['Show the real result screen','Brief reaction to the recorded score','Point out the Share button']),
 dict(id='10', type='share', title='Share your result.', kicker='BRING YOUR DRAFT GROUP',
      narration="Once you finish, use the Share button to post your result and compare with friends. It's an easy way to get everyone talking about the same decisions.", hold=.7),
 dict(id='11', type='daily', title='3 new Dailies.\nEvery day.', kicker='CHOOSE YOUR TABLE',
      narration="There are three new Dailies every day: Draft Run, Powered Cube, and Latest Set. Pick the one you want to play, or come back and try all three.", hold=1.0),
 dict(id='12', type='launch', title='Reality Fracture\nis live.', kicker='LATEST SET DAILY',
      narration="Reality Fracture is now live in the Latest Set Daily, so that's a good place to start if you're drafting the new format.", hold=1.5),
 dict(id='13', type='cta', title='Eight picks.\nYour call.', kicker='PLAY THE REALITY FRACTURE DAILY',
      narration="If you enjoy draft picks, give Pack One a try. The link below takes you straight to the Reality Fracture Daily. Play the eight picks, share your result, and tell me which decision gave you the most trouble. I'd love to hear what you think.", hold=3.0),
]

SHORT = "What would you take?\n\nPack One gives you eight picks from eight real trophy drafts. Make your choices, compare with the original drafters, and share your score.\n\nReality Fracture is live. Play at packone.pro."

@lru_cache(None)
def font(size, style='body'):
    paths = {'body':'SourceSans3-Regular.ttf', 'semi':'SourceSans3-Semibold.ttf',
             'bold':'SourceSans3-Bold.ttf', 'display':'BarlowCondensed-Semibold.ttf',
             'heavy':'BarlowCondensed-Bold.ttf'}
    return ImageFont.truetype(str(ASSETS / paths[style]), size)

def text(d, xy, value, size=42, fill=INK, style='body', anchor=None):
    d.text(xy, value, font=font(size,style), fill=fill, anchor=anchor,
           spacing=int(size*.12))

def wrap(d, value, width, size=36, style='body'):
    lines=[]
    for para in value.split('\n'):
        line=''
        for word in para.split():
            trial=(line+' '+word).strip()
            if d.textlength(trial,font=font(size,style)) > width and line:
                lines.append(line); line=word
            else: line=trial
        lines.append(line)
    return '\n'.join(lines)

LOGO=Image.open(ASSETS/'header-mark.png').convert('RGBA')

def mark(im, x, y, height):
    asset=LOGO.resize((int(height*LOGO.width/LOGO.height),height),Image.Resampling.LANCZOS)
    im.paste(asset,(int(x),int(y)),asset)

def header(im, d, scene):
    mark(im,72,48,62)
    text(d,(145,47),'Pack One',55,style='display')
    text(d,(1848,70),'LAUNCH VIDEO  /  REVIEW CUT',22,MUTED,'semi','ra')
    d.line((72,135,1848,135),fill=LINE,width=2)
    text(d,(72,1002),f"{scene['id']}  /  13",24,MUTED,'semi')
    text(d,(1848,1002),'packone.pro',27,BLUE,'semi','ra')

def cardback(im,d,x,y,w=205,h=285,number=None,selected=False):
    d.rounded_rectangle((x+6,y+9,x+w+6,y+h+9),18,fill='#e2e7ec')
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=BLUE if selected else 'white',outline=BLUE if selected else LINE,width=3)
    d.rounded_rectangle((x+13,y+13,x+w-13,y+h-13),10,outline='#6886a4' if selected else '#e3e9ee',width=2)
    if number:
        text(d,(x+w/2,y+h/2-5),str(number).zfill(2),78,'white' if selected else BLUE,'display','mm')
    else: mark(im,x+w/2-37,y+h/2-42,84)

def base(scene):
    im=Image.new('RGB',(W,H),PAGE); d=ImageDraw.Draw(im);header(im,d,scene)
    return im,d

def draw_scene(scene):
    im,d=base(scene); t=scene['type']
    text(d,(90,184),scene['kicker'],25,BLUE,'bold')
    if t in ('hook','eight'):
        text(d,(90,235),scene['title'],110,style='heavy')
        if t=='hook':
            text(d,(90,405),'Pause. Make your pick.\nSee what the trophy drafter chose.',40,MUTED)
            for i in range(5):cardback(im,d,690+i*216,360,194,282,i+1,i==2)
            text(d,(90,782),'RFA pack footage goes here in the final edit.',29,MUTED)
        else:
            for i in range(8):cardback(im,d,1000+(i%4)*206,250+(i//4)*295,185,265,i+1,i==0)
            text(d,(90,565),'Make your choices.\nCompare with the original drafters.\nFinish with a score to share.',39,MUTED)
    elif t=='source':
        text(d,(90,245),scene['title'],112,style='heavy')
        for x,n,cap in [(1020,'01','YOUR PICK'),(1430,'?','TROPHY PICK')]:
            cardback(im,d,x,302,285,392,n,x==1020)
            text(d,(x+142,735),cap,26,BLUE,'bold','mm')
        text(d,(90,603),'The real pack and reveal will replace\nthese neutral cards at launch.',33,MUTED)
    elif t=='insert':
        d.rounded_rectangle((90,248,1830,857),24,fill='white',outline=LINE,width=2)
        d.rounded_rectangle((132,292,374,335),8,fill=SOFT)
        text(d,(153,298),'FOOTAGE TO INSERT',22,BLUE,'bold')
        text(d,(132,373),scene['title'],105,style='heavy')
        text(d,(132,512),wrap(d,scene['subtitle'],1420,38),38,MUTED)
        for i,s in enumerate(scene['steps']):
            yy=652+i*55
            d.ellipse((136,yy+9,158,yy+31),fill=BLUE)
            text(d,(178,yy),s,32)
        text(d,(1825,208),f"{scene['duration']:.0f}s TIMED SLOT",23,MUTED,'semi','ra')
    elif t=='brand':
        mark(im,1070,280,390)
        text(d,(90,274),scene['title'],120,style='heavy')
        text(d,(90,468),'A daily challenge for people\nwho love draft decisions.',48,MUTED)
        text(d,(90,682),'Created by Ryan',28,BLUE,'semi')
    elif t=='thinking':
        text(d,(90,250),scene['title'],117,style='heavy')
        cards=[(1035,340,'A'),(1375,340,'B')]
        for x,y,n in cards:cardback(im,d,x,y,280,390,n,n=='A')
        text(d,(90,580),'Weigh the options.\nMake the call.\nSee another drafter’s perspective.',42,MUTED)
    elif t=='discussion':
        text(d,(90,245),scene['title'],119,style='heavy')
        rows=[('01','Your reasoning'),('02','Their choice'),('03','The conversation')]
        for i,(n,label) in enumerate(rows):
            y=300+i*155
            d.rounded_rectangle((1050,y,1820,y+120),12,fill='white',outline=LINE,width=2)
            text(d,(1085,y+22),n,60,BLUE,'display')
            text(d,(1190,y+34),label,40,style='semi')
        text(d,(90,590),'Bring the interesting picks\nto your draft group.',44,MUTED)
    elif t=='share':
        text(d,(90,245),scene['title'],125,style='heavy')
        text(d,(90,435),'Use the in-game Share button.\nCompare with your friends.',47,MUTED)
        d.rounded_rectangle((1110,350,1730,565),20,fill=BLUE)
        text(d,(1420,453),'Share result',66,'white','display','mm')
        text(d,(1420,626),'Your picks. Your score. Your group.',30,MUTED,'body','mm')
    elif t=='daily':
        text(d,(90,245),scene['title'],112,style='heavy')
        for i,(n,name,desc,col) in enumerate([
            ('01','Draft Run','Real trophy drafts',BLUE),
            ('02','Powered Cube','The powered table',GOLD),
            ('03','Latest Set','Reality Fracture at launch',BLUE)]):
            y=245+i*190
            d.rounded_rectangle((900,y,1820,y+155),12,fill='white',outline=LINE,width=2)
            d.rectangle((900,y+15,906,y+140),fill=col)
            text(d,(935,y+28),n,64,col,'display')
            text(d,(1040,y+22),name,59,style='display')
            text(d,(1040,y+91),desc,30,MUTED)
    elif t=='launch':
        d.rectangle((0,220,W,835),fill=DARK)
        text(d,(100,292),scene['title'],142,'white','heavy')
        text(d,(108,665),'LATEST SET DAILY  /  PACKONE.PRO',34,'#d7e4ef','semi')
        for i in range(3):cardback(im,d,1110+i*220,356,198,286,str(i+1),i==1)
        text(d,(90,866),'Launch wording is staged for the release, not a claim of current availability.',25,MUTED)
    elif t=='cta':
        mark(im,1290,266,310)
        text(d,(90,245),scene['title'],145,style='heavy')
        text(d,(90,650),'packone.pro',83,BLUE,'display')
        text(d,(90,776),'Play. Share your result. Tell us which pick was hardest.',37,MUTED)
    return im

def duration(path):
    with wave.open(str(path)) as f:return f.getnframes()/f.getframerate()

def write_wav(path,a,sr=22050):
    with wave.open(str(path),'wb') as f:
        f.setnchannels(1);f.setsampwidth(2);f.setframerate(sr);f.writeframes(a.astype('<i2').tobytes())

def wav_data(path):
    with wave.open(str(path)) as f:return np.frombuffer(f.readframes(f.getnframes()),dtype='<i2').copy(),f.getframerate()

def ts(sec):
    ms=int(round(sec*1000));h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);s,ms=divmod(ms,1000)
    return f'{h:02}:{m:02}:{s:02},{ms:03}'

def main():
    voice=None; sr=22050; start=0; captions=[]; audio=[]; timeline=[]
    for scene in SCENES:
        a_path=BUILD/f"{scene['id']}.wav"
        if scene.get('narration'):
            if not a_path.exists():
                if voice is None:
                    from piper import PiperVoice
                    from piper.config import SynthesisConfig
                    voice=PiperVoice.load(ROOT/'voice/en_US-ljspeech-high.onnx')
                with wave.open(str(a_path),'wb') as f:
                    voice.synthesize_wav(scene['narration'],f,SynthesisConfig(length_scale=1.13,noise_scale=.55,noise_w_scale=.7))
            samples,sr=wav_data(a_path)
        else:samples=np.zeros(0,dtype=np.int16)
        spoken=len(samples)/sr
        dur=max(scene.get('slot',0),spoken+scene.get('hold',.7)+.7)
        scene['duration']=round(dur,3)
        pad=np.zeros(int((dur-spoken)*sr),dtype=np.int16)
        combined=np.concatenate([np.zeros(int(.3*sr),dtype=np.int16),samples,pad])[:int(dur*sr)]
        write_wav(BUILD/f"{scene['id']}-padded.wav",combined,sr)
        audio.append(combined)
        if scene.get('narration'):
            sentences=re.split(r'(?<=[.!?])\s+',scene['narration'])
            weights=[len(s) for s in sentences]; elapsed=0
            for sentence,weight in zip(sentences,weights):
                dt=spoken*weight/sum(weights)
                words=sentence.split();chunks=[];chunk=[]
                for word in words:
                    if len(' '.join(chunk+[word]))>76 and chunk:chunks.append(' '.join(chunk));chunk=[]
                    chunk.append(word)
                if chunk:chunks.append(' '.join(chunk))
                for j,c in enumerate(chunks):
                    captions.append((start+.3+elapsed+dt*j/len(chunks),start+.3+elapsed+dt*(j+1)/len(chunks),c))
                elapsed+=dt
        scene['start']=round(start,3);scene['end']=round(start+dur,3)
        timeline.append(dict(scene))
        im=draw_scene(scene);im.save(BUILD/f"{scene['id']}.png")
        start+=dur
        print(f"Prepared {scene['id']}: {dur:.1f}s / {scene['title'].replace(chr(10),' ')}",flush=True)

    srt='\n\n'.join(f'{i+1}\n{ts(a)} --> {ts(b)}\n{s}' for i,(a,b,s) in enumerate(captions))+'\n'
    (OUT/'pack-one-launch-captions.srt').write_text(srt)
    (ROOT/'timeline.json').write_text(json.dumps(timeline,indent=2))
    (OUT/'pack-one-short-script.txt').write_text(SHORT+'\n')
    # Complete temporary voice track for replacing with a personal recording.
    voice_track=np.concatenate(audio)
    write_wav(OUT/'pack-one-launch-temp-narration.wav',voice_track,sr)
    # Render short scene files independently to keep memory and resume costs low.
    for scene in SCENES:
        clip=BUILD/f"{scene['id']}.mp4"
        if clip.exists() and clip.stat().st_size>1000:continue
        d=scene['duration']
        cmd=['ffmpeg','-y','-loglevel','error','-loop','1','-framerate',str(FPS),'-i',str(BUILD/f"{scene['id']}.png"),
             '-i',str(BUILD/f"{scene['id']}-padded.wav"),'-t',str(d),
             '-vf',f'fade=t=in:st=0:d=0.20:color=0xf7f8fa,fade=t=out:st={max(0,d-.20):.3f}:d=0.20:color=0xf7f8fa,format=yuv420p',
             '-c:v','libx264','-preset','veryfast','-crf','21','-threads','2','-c:a','aac','-b:a','160k','-ar','48000','-r',str(FPS),str(clip)]
        subprocess.run(cmd,check=True)
        print(f"Rendered scene {scene['id']}",flush=True)
    concat=BUILD/'concat.txt'
    concat.write_text(''.join(f"file '{BUILD / (s['id']+'.mp4')}'\n" for s in SCENES))
    output=OUT/'pack-one-launch-longform-review.mp4'
    subprocess.run(['ffmpeg','-y','-loglevel','error','-f','concat','-safe','0','-i',str(concat),'-i',str(OUT/'pack-one-launch-captions.srt'),
                    '-map','0:v:0','-map','0:a:0','-map','1:0','-c:v','copy','-c:a','copy','-c:s','mov_text',
                    '-metadata:s:s:0','language=eng','-metadata','title=Pack One launch — review cut',
                    '-movflags','+faststart',str(output)],check=True)
    # Contact sheet for a visual check, not an additional published asset.
    sheet=Image.new('RGB',(1440,math.ceil(len(SCENES)/3)*300),'white')
    sd=ImageDraw.Draw(sheet)
    for i,scene in enumerate(SCENES):
        thumb=Image.open(BUILD/f"{scene['id']}.png").resize((480,270),Image.Resampling.LANCZOS)
        x=(i%3)*480;y=(i//3)*300;sheet.paste(thumb,(x,y))
        text(sd,(x+8,y+272),f"{scene['start']:.1f}s — {scene['title'].replace(chr(10),' ')}",19,MUTED)
    sheet.save(BUILD/'contact-sheet.jpg',quality=90)
    print(json.dumps({'duration_seconds':start,'output':str(output),'bytes':output.stat().st_size}),flush=True)

if __name__=='__main__':main()
