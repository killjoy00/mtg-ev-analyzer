# Pack One launch video — review project

This is an editable production review cut, not a finished launch upload.

## What is built

- 1920 × 1080, 24 fps landscape MP4 with temporary synthetic narration.
- Pack One's canonical P¹ raster, Barlow Condensed and Source Sans 3 fonts, and current light scorecard palette.
- An introduction, the eight-pick explanation, sharing, the three Dailies, and the launch call to action.
- English captions as an embedded, switchable MP4 subtitle track and a separate SRT.
- A 34-word Short script, intended for about 15–20 seconds plus any thinking pause.
- Editable scene definitions, rendered scene artwork, individual narration files, and the full temporary voice track.

## Required gameplay inserts

On October 19, 2026, the public Latest Set Daily was The Hobbit. Reality Fracture did not appear in the playable dataset catalog. This project does not invent RFA packs, trophy selections, or scores.

Three visibly marked inserts remain:

1. RFA pick one: 22 seconds. Show a readable pack, explain your actual selection, reveal the trophy drafter's selection, and react.
2. RFA pick two: 25 seconds. Explain a real two-card tradeoff, choose, reveal, and react.
3. Finished RFA run: 9 seconds. Show the real result and Share button, with a brief reaction.

The opening and comparison artwork use neutral numbered cards as temporary framing. Replace those visuals with the same recorded RFA footage when completing the edit. These graphics are not screenshots of the game and are not representations of RFA cards.

The line “Reality Fracture is now live” is staged launch copy. Publish that wording only after RFA is actually available in Latest Set Daily. Remove the review labels when final footage and narration are approved.

## Voice

The review uses a generic synthetic voice, not Ryan's voice or a clone of it. The final first-person delivery is intended for Ryan, or can be rewritten into third person if a generic narrator is retained.

Temporary narration was synthesized locally with Piper and its en_US-ljspeech-high voice. That voice's model card identifies the source dataset as public domain:

- https://huggingface.co/rhasspy/piper-voices/blob/main/en/en_US/ljspeech/high/MODEL_CARD
- https://keithito.com/LJ-Speech-Dataset/

The project includes the rendered WAVs. A model download is not required to rebuild unchanged narration. The model binary is excluded from this package.

## Files and editing

- `timeline.json`: exact scene order, narration, timing, and footage notes.
- `recording-script.txt`: narration and insert directions for a personal recording.
- `build_video.py`: renderer. Use Python with Pillow and numpy, plus ffmpeg/ffprobe.
- `assets/`: canonical brand fonts and header mark.
- `render/NN.png`: scene artwork at full resolution.
- `render/NN.wav`: individual temporary narration segments.
- `deliverables/pack-one-launch-temp-narration.wav`: complete temporary voice track including insert timing.
- `deliverables/pack-one-launch-captions.srt`: English captions; update after replacing insert commentary or changing timing.
- `deliverables/pack-one-short-script.txt`: shortened Short.

To reproduce the review MP4, run `python build_video.py`. The supplied per-scene WAVs are reused. If regenerating narration, install `piper-tts`, download the documented public-domain-source voice into `voice/`, and remove only the narration files being replaced. Remove affected cached scene MP4s before rerendering.

For the final launch video, replace marked scenes with real RFA recordings and genuine pick commentary; conform the captions and timing to the finished edit. The included script and scene structure preserve the approved launch approach.
